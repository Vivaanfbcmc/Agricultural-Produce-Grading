# detect-final > ok
https://universe.roboflow.com/yas-workspace-rfjkr/detect-final-a5jit

Provided by a Roboflow user
License: CC BY 4.0

